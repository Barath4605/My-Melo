package com.atmymelo.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtMyMeloBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtMyMeloBackendApplication.class, args);
	}

}
